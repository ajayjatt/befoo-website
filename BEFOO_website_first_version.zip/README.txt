BEFOO WEBSITE — FIRST VERSION

1. index.html खोलकर website देख सकते हैं.
2. WhatsApp order link में 91XXXXXXXXXX को actual WhatsApp number से replace करें.
3. Product photos/logo को बाद में final brand assets से replace किया जा सकता है.
4. अभी direct online payment नहीं रखा गया है.
